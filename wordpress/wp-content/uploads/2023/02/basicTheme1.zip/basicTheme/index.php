<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Document</title>
</head>
<body class="bg-slate-200">
    <div class="container mx-auto items-center justify-center w-2/3">
        <div class="grid gap-y-10 lg:grid-cols-3 md:grid-cols-2 sm:grid-cols-1 justify-center items-center h-screen">
            <div class="mx-auto p-5">
                <img class="rounded-md shadow-md" src="https://picsum.photos/id/237/250/200" alt="">
                <p class="font-bold text-md">Matthew Taylor</p>
                <a class="font-semibold text-red-500 text-sm" href="https://google.com/#">View Portfolio</a>
            </div>

            <div class="mx-auto p-5">
                <img class="rounded-md shadow-md" src="https://picsum.photos/id/144/250/200" alt="">
                <p class="font-bold text-md">Kevin White</p>
                <a class="font-semibold text-red-500 text-sm" href="https://google.com/#">View Portfolio</a>
            </div>

            <div class="mx-auto p-5">
                <img class="rounded-md shadow-md" src="https://picsum.photos/id/123/250/200" alt="">
                <p class="font-bold text-md">John Brook</p>
                <a class="font-semibold text-red-500 text-sm" href="https://google.com/#">View Portfolio</a>
            </div>
        </div>
    </div>
</body>
</html>